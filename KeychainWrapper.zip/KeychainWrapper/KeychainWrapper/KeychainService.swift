//
//  KeychainServices.swift
//  NFoundation
//
//  Created by Sandeep Kakde on 06/03/19.
//  Copyright © 2019 Sandeep Kakde. All rights reserved.
//

import Foundation

let kSecClassValue = String(format: kSecClass as String)
let kSecValueDataValue = String(format: kSecValueData as String)
let kSecClassGenericPasswordValue = String(format: kSecClassGenericPassword as String)
let kSecAttrServiceValue = String(format: kSecAttrService as String)
let kSecMatchLimitValue = String(format: kSecMatchLimit as String)
let kSecReturnDataValue = String(format: kSecReturnData as String)
let kSecMatchLimitOneValue = String(format: kSecMatchLimitOne as String)
let kSecAttrAccessibleValue = String(format: kSecAttrAccessible as String)


var loggingEnabled = false
public func logPrint(_ items: Any...) {
    if loggingEnabled {
        print(items)
    }
}

open class KeychainService {
    private static var shared: KeychainService!
    public static var sharedInstance: KeychainService {
        get {
            if shared == nil {
                DispatchQueue.global().sync() {
                    if shared == nil {
                        shared = KeychainService()
                    }
                }
            }
            return shared
        }
    }
    
    public func updateSecureData(key: String, value: String) -> Bool {
        if let dataFromString: Data = value.data(using: String.Encoding.utf8, allowLossyConversion: false) {
            let query = getKeychainQuery(with: key)
            let status = SecItemUpdate(query as CFDictionary, [kSecValueDataValue: dataFromString] as CFDictionary)
            if (status != errSecSuccess) {
                if let err = SecCopyErrorMessageString(status, nil) {
                    logPrint("Update failed:: \(err) ")
                }
                return false
            } else {
                return true
            }
        }
        return false
    }
    
    public func removeSecureData(key: String) -> Bool {
        let query = getKeychainQuery(with: key)
        query.setValue(kCFBooleanTrue, forKey: kSecReturnDataValue)
        let status = SecItemDelete(query as CFDictionary)
        if (status != errSecSuccess) {
            if let err = SecCopyErrorMessageString(status, nil) {
                logPrint("Remove failed:: \(err) ")
            }
            return false
            
        } else {
            return true
        }
    }
    
    public func saveSecureData(key: String, value: String) -> Bool {
        if let dataFromString = value.data(using: String.Encoding.utf8, allowLossyConversion: false) {
            let query = getKeychainQuery(with: key)
            query.setValue(dataFromString, forKey: kSecValueDataValue)
            let status = SecItemAdd(query as CFDictionary, nil)
            if (status != errSecSuccess) {
                if let err = SecCopyErrorMessageString(status, nil) {
                    logPrint("save failed:: \(err) ")
                    return false
                }
            } else {
                return true
            }
        }
        return false
    }
    
    public func loadSecureData(key: String) -> String? {
        let query = getKeychainQuery(with: key)
        query.setValue(kCFBooleanTrue, forKey: kSecReturnDataValue)
        query.setValue(kSecMatchLimitOneValue, forKey: kSecMatchLimitValue)
        var dataTypeRef: AnyObject?
        let status: OSStatus = SecItemCopyMatching(query, &dataTypeRef)
        var contentsOfKeychain: String?
        
        if status == errSecSuccess {
            if let retrievedData = dataTypeRef as? Data {
                contentsOfKeychain = String(data: retrievedData, encoding: String.Encoding.utf8)
            }
        } else {
            logPrint("keychain is empty. Status code: \(status) ")
            
        }
        return contentsOfKeychain
    }
    
    private func getKeychainQuery(with key: String) -> NSMutableDictionary {
        let result = NSMutableDictionary()
        result.setValue(kSecClassGenericPasswordValue, forKey: kSecClassValue)
        result.setValue(key, forKey: kSecAttrServiceValue)
        result.setValue(kSecAttrAccessibleAlwaysThisDeviceOnly, forKey: kSecAttrAccessibleValue)
        return result
    }
}
