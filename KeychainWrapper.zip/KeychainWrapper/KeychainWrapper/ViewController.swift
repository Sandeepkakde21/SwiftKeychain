//
//  ViewController.swift
//  KeychainWrapper
//
//  Created by Sandeep Kakde on 16/03/19.
//  Copyright © 2019 Sandeep Kakde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //Keychain service
        let keychaine = KeychainService.sharedInstance
        print(keychaine.saveSecureData(key: "key", value: "sandeep"))
        print(keychaine.loadSecureData(key: "key")!)
        print(keychaine.updateSecureData(key: "key", value: "sandeep Kakde"))
        print(keychaine.loadSecureData(key: "key") ?? "")
        print(keychaine.updateSecureData(key: "key123", value: "sandeep Kakde"))
        print(keychaine.removeSecureData(key: "key"))
        print(keychaine.loadSecureData(key: "key") ?? "")
    }


}

